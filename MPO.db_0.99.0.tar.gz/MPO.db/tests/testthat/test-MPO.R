test_that("HDOANCESTOR", {
    aa <- length(as.list(MPOANCESTOR))
    expect_true(aa > 0)
})
