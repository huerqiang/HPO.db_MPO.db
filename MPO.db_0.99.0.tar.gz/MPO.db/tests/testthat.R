library(testthat)
library(MPO.db)
test_check("MPO.db")
