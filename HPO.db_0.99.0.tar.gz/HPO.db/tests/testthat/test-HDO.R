test_that("HPOANCESTOR", {
    aa <- length(as.list(HPOANCESTOR))
    expect_true(aa > 0)
})
