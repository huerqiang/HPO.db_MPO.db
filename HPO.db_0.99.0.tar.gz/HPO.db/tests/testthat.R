library(testthat)
library(HPO.db)
test_check("HPO.db")
